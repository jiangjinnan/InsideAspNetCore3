﻿using System;
using System.Collections.Generic;
using System.Text;

namespace App
{
    public interface IFeatureCollection : IDictionary<Type, object> { }
}
