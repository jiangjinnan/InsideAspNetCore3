﻿using System;
using System.Collections.Generic;

namespace App
{
    public class FeatureCollection : Dictionary<Type, object>, IFeatureCollection { }
}
