﻿namespace App
{
    public enum Lifetime
    {
        Root,
        Self,
        Transient
    }
}