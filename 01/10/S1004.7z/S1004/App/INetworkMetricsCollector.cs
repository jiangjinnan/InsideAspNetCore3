﻿namespace App
{
    public interface INetworkMetricsCollector
    {
        long GetThroughput();
    }
}