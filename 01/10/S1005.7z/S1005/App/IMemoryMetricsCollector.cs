﻿namespace App
{
    public interface IMemoryMetricsCollector
    {
        long GetUsage();
    }
}