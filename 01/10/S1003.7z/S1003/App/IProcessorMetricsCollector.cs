﻿namespace App
{
    public interface IProcessorMetricsCollector
    {
        int GetUsage();
    }
}